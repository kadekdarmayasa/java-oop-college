NIM   : 230030008
NAMA  : I Kadek Darmayasa Adi Putra

Tautan Video: 
https://youtu.be/08kFO9MsZdk