package soal1;

public class Mahasiswa {
    // Atribut mahasiswa
    String nama;
    String nim;
    String prodi;
    double ipk;

    // Constructor untuk inisialisasi atribut
    public Mahasiswa(String nama, String nim, String prodi, double ipk) {
        this.nama = nama;
        this.nim = nim;
        this.prodi = prodi;
        this.ipk = ipk;
    }
}