package bab_04;

public class PercabanganOperatorLogika {
    public static void main(String[] args) {
        int nilai = 75;
        String keterangan;

        // Operator ternary untuk percabangan IF/ELSE
        keterangan = nilai > 70 ? "lulus" : "gagal";

        System.out.println(keterangan);
    }
}
