public class Manusia {
    String nama;
    int umur;

    void perkenalanDiri() {
        System.out.println("Halo nama saya " + nama + ", umur saya " + umur);
    }
}
